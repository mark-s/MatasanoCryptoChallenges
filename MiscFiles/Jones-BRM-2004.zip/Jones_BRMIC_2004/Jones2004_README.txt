These files are associated with the article Jones & Mewhort (2004). "Case sensitive letter and bigram frequency counts from large-scale English corpora." Behavior Research Methods, Instruments, & Computers. 

Each directory contains a different format of the same two files (the single letter and bigram counts). Variable names are included at the top of each data file. 

\TXT: tab-delimited pure text files, character values are the actual characters (this may cause read problems with some software as some of the entries maybe treated as special characters).

\XLS: Microsoft Excel 2000 files. 

\PDF: Adobe Acrobat portable document format. Only use these files as a last resort if you cannot read the other files into your stimuli program or spreadsheet. The characters will stay in their appointed columns rather than being treated as special characters.

\ASC: space-delimited pure text, the character values are coded with their ASCII order integer (33-126). We recommend this format if reading files into other software; most programming languages have ASCII-to-character conversion routines. 

Following are the generic descriptions of the two files in each directory: 

Jones2004_Single.*: 
-----------------------------
Contains single-character frequency counts (ASCII 33-126; ! to ~) tabulated from each corpus (New York Times, Encyclopedia, Brown, Webpage, Newsgroup). Variable names are at the top of the data file. 

Jones2004_Bigram.*:
------------------------------ 
Contains bigram counts for each combination of characters (ASCII 33-126; ! to ~) tabulated from each corpus (New York Times, Encyclopedia, Brown, Webpage, Newsgroup). Variable names are at the top of the data file. 

The first two variables contain the character values of the predecessor and successor (respectively) for a bigram. Bigrams were defined as directly adjacent characters. Thus, in the previous sentence, the period is considered a successor to the "s" ("characters."), but at the beginning of this sentence, the period is not considered a predecessor to the "T" in "Thus" (since there is an intermediate space).

The bigram output was written so that predecessor is the fastest moving index (ASCII 33-126) within the slower-moving index of successor (ASCII 33-126).  

For questions regarding these files, please email mike@psyc.queensu.ca


